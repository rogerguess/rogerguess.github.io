#!/usr/bin/python
import sys
import os
import Image
import ImageDraw
import time
import curses
from rgbmatrix import Adafruit_RGBmatrix


# Rows and chain length are both required parameters:
matrix = Adafruit_RGBmatrix(32, 2)

dir = os.path.dirname(__file__)
filename = os.path.join(dir, sys.argv[1])

image = Image.open(filename)
image.load()
pics = []
imRGBA = image.copy()
try:
	while True:
		imRGBA = image.copy()
		frame = imRGBA.convert('RGBA')
		pics.append(frame)
		image.seek(len(pics))
except EOFError: pass

matrix.Clear()

while True:
	for item in pics[1:]:
		matrix.SetImage(item.im.id, 0, 0)
		time.sleep(0.1)

matrix.Clear()
